"use client"

import * as React from "react"
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query"
import { toast } from "sonner"
import { Pencil, Plus, Trash2, Eye } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { DataTable, type Column } from "@/components/data-table"
import { FormDialog } from "@/components/form-dialog"
import { ConfirmDialog } from "@/components/confirm-dialog"
import { SearchableSelect } from "@/components/searchable-select"
import { PageHeader } from "@/components/page-header"
import type { InventoryStock, Product, Uom, Brand } from "@/lib/types"
import { formatDate, toInputDate } from "@/lib/format"

interface FormState {
  id?: string
  date: string
  invoice: string
  productId: string | null
  brand: string
  model: string
  serial: string
  qty: string
  uom: string
  remarks: string
}

const empty = (): FormState => ({
  date: toInputDate(new Date()),
  invoice: "",
  productId: null,
  brand: "",
  model: "",
  serial: "",
  qty: "1",
  uom: "",
  remarks: "",
})

export function InventoryModule() {
  const qc = useQueryClient()
  const [search, setSearch] = React.useState("")
  const [open, setOpen] = React.useState(false)
  const [editing, setEditing] = React.useState<FormState | null>(null)
  const [deletingId, setDeletingId] = React.useState<string | null>(null)
  const [viewing, setViewing] = React.useState<InventoryStock | null>(null)

  const { data, isLoading } = useQuery<InventoryStock[]>({
    queryKey: ["inventory"],
    queryFn: async () => {
      const res = await fetch("/api/inventory")
      if (!res.ok) throw new Error("Failed")
      return res.json()
    },
  })

  const { data: products } = useQuery<Product[]>({
    queryKey: ["products"],
    queryFn: async () => {
      const res = await fetch("/api/products")
      if (!res.ok) throw new Error("Failed")
      return res.json()
    },
  })

  const { data: uoms } = useQuery<Uom[]>({
    queryKey: ["uoms"],
    queryFn: async () => {
      const res = await fetch("/api/uoms")
      if (!res.ok) throw new Error("Failed")
      return res.json()
    },
  })

  const { data: brands } = useQuery<Brand[]>({
    queryKey: ["brands"],
    queryFn: async () => {
      const res = await fetch("/api/brands")
      if (!res.ok) throw new Error("Failed")
      return res.json()
    },
  })

  const saveMutation = useMutation({
    mutationFn: async (data: FormState) => {
      const payload = {
        id: data.id,
        date: data.date,
        invoice: data.invoice,
        productId: data.productId || null,
        brand: data.brand,
        model: data.model,
        serial: data.serial,
        qty: Number(data.qty) || 0,
        uom: data.uom,
        remarks: data.remarks,
      }
      const isEdit = !!data.id
      const res = await fetch("/api/inventory", {
        method: isEdit ? "PUT" : "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      })
      if (!res.ok) throw new Error("Save failed")
      return res.json()
    },
    onSuccess: () => {
      toast.success("Inventory record saved")
      qc.invalidateQueries({ queryKey: ["inventory"] })
      qc.invalidateQueries({ queryKey: ["stats"] })
      setOpen(false)
      setEditing(null)
    },
    onError: (e: Error) => toast.error(e.message),
  })

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      const res = await fetch(`/api/inventory?id=${id}`, { method: "DELETE" })
      if (!res.ok) throw new Error("Delete failed")
      return res.json()
    },
    onSuccess: () => {
      toast.success("Inventory record deleted")
      qc.invalidateQueries({ queryKey: ["inventory"] })
      qc.invalidateQueries({ queryKey: ["stats"] })
      setDeletingId(null)
    },
    onError: (e: Error) => toast.error(e.message),
  })

  const rows = React.useMemo(() => {
    const list = data ?? []
    if (!search) return list
    const s = search.toLowerCase()
    return list.filter(
      (i) =>
        i.invoice.toLowerCase().includes(s) ||
        i.brand?.toLowerCase().includes(s) ||
        i.model?.toLowerCase().includes(s) ||
        i.serial?.toLowerCase().includes(s) ||
        i.product?.name.toLowerCase().includes(s)
    )
  }, [data, search])

  const handleAdd = () => {
    setEditing(empty())
    setOpen(true)
  }
  const handleEdit = (row: InventoryStock) => {
    setEditing({
      id: row.id,
      date: toInputDate(row.date),
      invoice: row.invoice,
      productId: row.productId,
      brand: row.brand ?? "",
      model: row.model ?? "",
      serial: row.serial ?? "",
      qty: String(row.qty),
      uom: row.uom ?? "",
      remarks: row.remarks ?? "",
    })
    setOpen(true)
  }
  const handleSubmit = () => {
    if (!editing) return
    if (!editing.invoice.trim()) {
      toast.error("Invoice is required")
      return
    }
    saveMutation.mutate(editing)
  }

  const handleProductChange = (pid?: string) => {
    if (!editing) return
    const product = (products ?? []).find((p) => p.id === pid)
    setEditing({
      ...editing,
      productId: pid || null,
      brand: product?.brand?.name ?? editing.brand,
      model: product?.model ?? editing.model,
      serial: product?.serial ?? editing.serial,
      uom: product?.uom?.name ?? editing.uom,
    })
  }

  const handleBrandChange = (v?: string) => {
    if (!editing) return
    setEditing({ ...editing, brand: v ?? "" })
  }

  const columns: Column<InventoryStock>[] = [
    {
      key: "date",
      header: "Date",
      cell: (row) => (
        <span className="text-muted-foreground text-xs">{formatDate(row.date)}</span>
      ),
    },
    { key: "invoice", header: "Invoice", cell: (row) => <span className="text-xs">{row.invoice}</span> },
    { key: "product", header: "Product", cell: (row) => <span className="text-xs">{row.product?.name ?? "—"}</span> },
    { key: "brand", header: "Brand", cell: (row) => <span className="text-xs">{row.brand ?? "—"}</span> },
    { key: "model", header: "Model", cell: (row) => <span className="text-xs">{row.model ?? "—"}</span> },
    { key: "serial", header: "Serial", cell: (row) => <span className="text-xs font-mono">{row.serial ?? "—"}</span> },
    { key: "condition", header: "Condition", cell: (row) => <span className="text-xs">{row.condition ?? "—"}</span> },
    { key: "warrantyText", header: "Warranty", cell: (row) => <span className="text-xs">{row.warrantyText ?? "—"}</span> },
    { key: "qty", header: "Qty", cell: (row) => <span className="text-xs font-medium">{row.qty}</span> },
    { key: "uom", header: "UOM", cell: (row) => <span className="text-xs">{row.uom ?? row.product?.uom?.name ?? "—"}</span> },
    {
      key: "remarks",
      header: "Remarks",
      cell: (row) => (
        <span className="text-muted-foreground text-xs max-w-xs truncate">
          {row.remarks ?? "—"}
        </span>
      ),
    },
    {
      key: "actions",
      header: "Action",
      cell: (row) => (
        <div className="flex items-center gap-1">
          <Button size="icon" variant="ghost" onClick={() => setViewing(row)} title="View">
            <Eye className="h-4 w-4" />
          </Button>
          <Button size="icon" variant="ghost" onClick={() => handleEdit(row)} title="Edit">
            <Pencil className="h-4 w-4" />
          </Button>
          <Button
            size="icon"
            variant="ghost"
            onClick={() => setDeletingId(row.id)}
            title="Delete"
            className="text-destructive hover:text-destructive"
          >
            <Trash2 className="h-4 w-4" />
          </Button>
        </div>
      ),
    },
  ]

  return (
    <div className="flex flex-col gap-4">
      <PageHeader
        title="Inventory Stock"
        description="Track stock movements and current inventory."
      />

      <DataTable
        columns={columns}
        rows={rows}
        rowKey={(r) => r.id}
        loading={isLoading}
        search
        searchText={search}
        onSearchChange={setSearch}
        searchPlaceholder="Search inventory..."
        headerRowClassName="bg-gradient-to-r from-emerald-500 via-emerald-600 to-teal-700 hover:from-emerald-500 hover:via-emerald-600 hover:to-teal-700 [&>th]:text-white [&>th]:font-bold"
      />

      <FormDialog
        open={open}
        onOpenChange={setOpen}
        title={editing?.id ? "Edit Stock" : "Add Stock"}
        size="lg"
        onSubmit={handleSubmit}
        loading={saveMutation.isPending}
        submitLabel={editing?.id ? "Update" : "Create"}
      >
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <div className="grid gap-2">
            <Label>Date</Label>
            <Input
              type="date"
              value={editing?.date ?? ""}
              onChange={(e) =>
                setEditing({ ...editing!, date: e.target.value })
              }
            />
          </div>
          <div className="grid gap-2">
            <Label>Invoice</Label>
            <Input
              value={editing?.invoice ?? ""}
              onChange={(e) =>
                setEditing({ ...editing!, invoice: e.target.value })
              }
              placeholder="INV-001"
            />
          </div>
          <div className="grid gap-2 sm:col-span-2">
            <Label>Product</Label>
            <SearchableSelect
              value={editing?.productId ?? null}
              onValueChange={handleProductChange}
              options={(products ?? []).map((p) => ({ value: p.id, label: p.name, hint: p.category?.name }))}
              placeholder="Select product"
              searchPlaceholder="Search product..."
              emptyText="No product found."
              allowNone
              noneLabel="— None —"
            />
          </div>
          <div className="grid gap-2">
            <Label>Brand</Label>
            <SearchableSelect
              value={editing?.brand || null}
              onValueChange={handleBrandChange}
              options={(brands ?? []).map((b) => ({ value: b.name, label: b.name }))}
              placeholder="—"
              searchPlaceholder="Search brand..."
              emptyText="No brand found."
              allowNone
              noneLabel="—"
            />
          </div>
          <div className="grid gap-2">
            <Label>Model</Label>
            <Input
              value={editing?.model ?? ""}
              onChange={(e) =>
                setEditing({ ...editing!, model: e.target.value })
              }
            />
          </div>
          <div className="grid gap-2">
            <Label>Serial</Label>
            <Input
              value={editing?.serial ?? ""}
              onChange={(e) =>
                setEditing({ ...editing!, serial: e.target.value })
              }
            />
          </div>
          <div className="grid gap-2">
            <Label>Qty</Label>
            <Input
              type="number"
              value={editing?.qty ?? ""}
              onChange={(e) =>
                setEditing({ ...editing!, qty: e.target.value })
              }
            />
          </div>
          <div className="grid gap-2">
            <Label>UOM</Label>
            <Select
              value={editing?.uom || "none"}
              onValueChange={(v) =>
                setEditing({
                  ...editing!,
                  uom: v === "none" ? "" : v,
                })
              }
            >
              <SelectTrigger className="w-full">
                <SelectValue placeholder="Select UOM" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="none">— None —</SelectItem>
                {(uoms ?? []).map((u) => (
                  <SelectItem key={u.id} value={u.name}>
                    {u.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="grid gap-2 sm:col-span-2">
            <Label>Remarks</Label>
            <Textarea
              value={editing?.remarks ?? ""}
              onChange={(e) =>
                setEditing({ ...editing!, remarks: e.target.value })
              }
              rows={2}
            />
          </div>
        </div>
      </FormDialog>

            {/* View dialog */}
      <FormDialog
        open={!!viewing}
        onOpenChange={(o) => !o && setViewing(null)}
        title={`Inventory ${viewing?.invoice ?? ""}`}
        size="md"
        hideFooter
        footer={<Button variant="outline" onClick={() => setViewing(null)}>Close</Button>}
      >
        {viewing && (
          <div className="grid grid-cols-1 gap-2 text-sm sm:grid-cols-2">
            <div><span className="text-muted-foreground">Date:</span> <span className="font-medium">{formatDate(viewing.date)}</span></div>
            <div><span className="text-muted-foreground">Invoice:</span> <span className="font-medium">{viewing.invoice}</span></div>
            <div><span className="text-muted-foreground">Product:</span> <span className="font-medium">{viewing.product?.name ?? "—"}</span></div>
            <div><span className="text-muted-foreground">Brand:</span> <span className="font-medium">{viewing.brand ?? "—"}</span></div>
            <div><span className="text-muted-foreground">Model:</span> <span className="font-medium">{viewing.model ?? "—"}</span></div>
            <div><span className="text-muted-foreground">Serial:</span> <span className="font-mono text-sm">{viewing.serial ?? "—"}</span></div>
            <div><span className="text-muted-foreground">Condition:</span> <span className="font-medium">{viewing.condition ?? "—"}</span></div>
            <div><span className="text-muted-foreground">Warranty:</span> <span className="font-medium">{viewing.warrantyText ?? "—"}</span></div>
            <div><span className="text-muted-foreground">Qty:</span> <span className="font-medium">{viewing.qty}</span></div>
            <div><span className="text-muted-foreground">UOM:</span> <span className="font-medium">{viewing.uom ?? viewing.product?.uom?.name ?? "—"}</span></div>
            <div className="sm:col-span-2"><span className="text-muted-foreground">Remarks:</span> <span>{viewing.remarks ?? "—"}</span></div>
          </div>
        )}
      </FormDialog>

      <ConfirmDialog
        open={!!deletingId}
        onOpenChange={(o) => !o && setDeletingId(null)}
        title="Delete inventory record?"
        description="This will permanently delete the record."
        loading={deleteMutation.isPending}
        onConfirm={() => deletingId && deleteMutation.mutate(deletingId)}
      />
    </div>
  )
}
